type AppRouteName =
  | "MainTabs"
  | "MyBookingScreen"
  | "PaymentSuccessScreen"
  | "PaymentFailedScreen";

type ResetRoute = {
  name: AppRouteName;
  params?: Record<string, unknown>;
};

export type PaymentResultRouteName = "PaymentSuccessScreen" | "PaymentFailedScreen";

export type NavigationResetState = {
  index: number;
  routes: ResetRoute[];
};

export function buildMainTabsResetState(): NavigationResetState {
  return {
    index: 0,
    routes: [{ name: "MainTabs" }],
  };
}

export function buildMyBookingResetState(): NavigationResetState {
  return {
    index: 1,
    routes: [{ name: "MainTabs" }, { name: "MyBookingScreen" }],
  };
}

export function buildPaymentResultResetState(
  routeName: PaymentResultRouteName,
  params: Record<string, unknown>
): NavigationResetState {
  return {
    index: 1,
    routes: [{ name: "MainTabs" }, { name: routeName, params }],
  };
}
