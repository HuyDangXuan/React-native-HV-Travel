const {
  buildPaymentResultResetState,
  buildMainTabsResetState,
  buildMyBookingResetState,
} = require("../.test-dist/utils/paymentNavigation");

describe("payment navigation reset helpers", () => {
  test("builds success reset state that drops booking and payment history", () => {
    const params = {
      id: "TOUR-001",
      total: 2450000,
      amountText: "2.450.000 ₫",
      orderId: "DL123456",
      method: "ZaloPay",
    };

    expect(buildPaymentResultResetState("PaymentSuccessScreen", params)).toEqual({
      index: 1,
      routes: [
        { name: "MainTabs" },
        { name: "PaymentSuccessScreen", params },
      ],
    });
  });

  test("builds failed reset state that keeps only main tabs and failed result", () => {
    const params = {
      id: "TOUR-001",
      total: 2450000,
      amountText: "2.450.000 ₫",
      orderId: "DL123456",
      method: "VNPay",
      reason: "timeout",
    };

    expect(buildPaymentResultResetState("PaymentFailedScreen", params)).toEqual({
      index: 1,
      routes: [
        { name: "MainTabs" },
        { name: "PaymentFailedScreen", params },
      ],
    });
  });

  test("builds a home reset state for result CTA", () => {
    expect(buildMainTabsResetState()).toEqual({
      index: 0,
      routes: [{ name: "MainTabs" }],
    });
  });

  test("builds a booked-trips reset state for result CTA", () => {
    expect(buildMyBookingResetState()).toEqual({
      index: 1,
      routes: [{ name: "MainTabs" }, { name: "MyBookingScreen" }],
    });
  });
});
